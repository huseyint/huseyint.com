﻿using System;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.ComponentModel;

namespace Huseyint.Controls
{
    public class CueBannerTextBox : TextBox
    {
        #region Win32 API
        internal const uint ECM_FIRST = 0x1500;
        internal const uint EM_SETCUEBANNER = ECM_FIRST + 1;

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        internal static extern IntPtr SendMessage(HandleRef hWnd, uint msg, bool wParam, string lParam);
        #endregion

        // Cue banners are supported on Windows XP (5.1) and above
        private static bool isSupported = (
            (Environment.OSVersion.Version.Major == 5 && Environment.OSVersion.Version.Minor == 1)
            || Environment.OSVersion.Version.Major > 5);


        private string _cueBannerText;
        private bool _cueBannerShowOnFocus;

        /// <summary>
        /// Sets the cue banner initially.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);

            SetCueBanner();
        }

        /// <summary>
        /// Gets or sets the cue banner text.
        /// </summary>
        [DefaultValue(default(string))]
        [Description("The text to display as the textual cue.")]
        [Category("Appearance")]
        public string CueBannerText
        {
            get
            {
                return _cueBannerText;
            }
            set
            {
                if (_cueBannerText != value)
                {
                    _cueBannerText = value;

                    SetCueBanner();
                }
            }
        }

        /// <summary>
        /// Gets or sets whether cue banner should show when focused. This only works for Vista.
        /// </summary>
        [DefaultValue(default(bool))]
        [Description("Indicates whether the cue banner should show even when the edit control has focus. (Vista only)")]
        [Category("Appearance")]
        public bool CueBannerShowOnFocus
        {
            get
            {
                return _cueBannerShowOnFocus;
            }
            set
            {
                if (_cueBannerShowOnFocus != value)
                {
                    _cueBannerShowOnFocus = value;

                    SetCueBanner();
                }
            }
        }

        /// <summary>
        /// Sets the cue banner according to current parameters.
        /// </summary>
        private void SetCueBanner()
        {
            if (isSupported)
            {
                SendMessage(new HandleRef(this, this.Handle), EM_SETCUEBANNER, _cueBannerShowOnFocus, _cueBannerText);
            }
        }
    }
}