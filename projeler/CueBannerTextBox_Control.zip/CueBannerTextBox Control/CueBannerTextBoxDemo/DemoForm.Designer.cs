﻿namespace CueBannerTextBoxDemo
{
    partial class DemoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbSettings = new System.Windows.Forms.GroupBox();
            this.chkShowOnFocus = new System.Windows.Forms.CheckBox();
            this.txtCueBannerText = new System.Windows.Forms.TextBox();
            this.lblCueBannerText = new System.Windows.Forms.Label();
            this.grbPreview = new System.Windows.Forms.GroupBox();
            this.txtPreview = new Huseyint.Controls.CueBannerTextBox();
            this.grbSettings.SuspendLayout();
            this.grbPreview.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbSettings
            // 
            this.grbSettings.Controls.Add(this.chkShowOnFocus);
            this.grbSettings.Controls.Add(this.txtCueBannerText);
            this.grbSettings.Controls.Add(this.lblCueBannerText);
            this.grbSettings.Location = new System.Drawing.Point(12, 12);
            this.grbSettings.Name = "grbSettings";
            this.grbSettings.Size = new System.Drawing.Size(317, 77);
            this.grbSettings.TabIndex = 0;
            this.grbSettings.TabStop = false;
            this.grbSettings.Text = "Cue Banner Settings";
            // 
            // chkShowOnFocus
            // 
            this.chkShowOnFocus.AutoSize = true;
            this.chkShowOnFocus.Location = new System.Drawing.Point(102, 49);
            this.chkShowOnFocus.Name = "chkShowOnFocus";
            this.chkShowOnFocus.Size = new System.Drawing.Size(180, 17);
            this.chkShowOnFocus.TabIndex = 2;
            this.chkShowOnFocus.Text = "Show even on focus (Vista only)";
            this.chkShowOnFocus.UseVisualStyleBackColor = true;
            this.chkShowOnFocus.CheckedChanged += new System.EventHandler(this.chkShowOnFocues_CheckedChanged);
            // 
            // txtCueBannerText
            // 
            this.txtCueBannerText.Location = new System.Drawing.Point(102, 23);
            this.txtCueBannerText.Name = "txtCueBannerText";
            this.txtCueBannerText.Size = new System.Drawing.Size(209, 21);
            this.txtCueBannerText.TabIndex = 1;
            this.txtCueBannerText.Text = "Search";
            this.txtCueBannerText.TextChanged += new System.EventHandler(this.txtCueBannerText_TextChanged);
            // 
            // lblCueBannerText
            // 
            this.lblCueBannerText.AutoSize = true;
            this.lblCueBannerText.Location = new System.Drawing.Point(6, 26);
            this.lblCueBannerText.Name = "lblCueBannerText";
            this.lblCueBannerText.Size = new System.Drawing.Size(92, 13);
            this.lblCueBannerText.TabIndex = 0;
            this.lblCueBannerText.Text = "Cue Banner Text:";
            // 
            // grbPreview
            // 
            this.grbPreview.Controls.Add(this.txtPreview);
            this.grbPreview.Location = new System.Drawing.Point(12, 95);
            this.grbPreview.Name = "grbPreview";
            this.grbPreview.Size = new System.Drawing.Size(317, 67);
            this.grbPreview.TabIndex = 1;
            this.grbPreview.TabStop = false;
            this.grbPreview.Text = "Preview";
            // 
            // txtPreview
            // 
            this.txtPreview.CueBannerText = "Search";
            this.txtPreview.Location = new System.Drawing.Point(6, 30);
            this.txtPreview.Name = "txtPreview";
            this.txtPreview.Size = new System.Drawing.Size(305, 21);
            this.txtPreview.TabIndex = 0;
            // 
            // DemoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(341, 174);
            this.Controls.Add(this.grbPreview);
            this.Controls.Add(this.grbSettings);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "DemoForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CueBannerTextBox Control Demo";
            this.grbSettings.ResumeLayout(false);
            this.grbSettings.PerformLayout();
            this.grbPreview.ResumeLayout(false);
            this.grbPreview.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbSettings;
        private System.Windows.Forms.CheckBox chkShowOnFocus;
        private System.Windows.Forms.TextBox txtCueBannerText;
        private System.Windows.Forms.Label lblCueBannerText;
        private System.Windows.Forms.GroupBox grbPreview;
        private Huseyint.Controls.CueBannerTextBox txtPreview;
    }
}

