﻿using System.Windows.Forms;

namespace CueBannerTextBoxDemo
{
    public partial class DemoForm : Form
    {
        public DemoForm()
        {
            InitializeComponent();
        }

        private void txtCueBannerText_TextChanged(object sender, System.EventArgs e)
        {
            txtPreview.CueBannerText = txtCueBannerText.Text;
        }

        private void chkShowOnFocues_CheckedChanged(object sender, System.EventArgs e)
        {
            txtPreview.CueBannerShowOnFocus = chkShowOnFocus.Checked;
        }

    }
}
